package com.example.myapp2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    TextView txtWord_Guess;
    String word_guess; // wordsToBeGuessed
    EditText editInput;




    ArrayList<String> wordbanks; //myListofWords
    String wordDisplayedString;
    char[] wordDisplayedCharArray;

    TextView txtLettersUsed;

    String lettersUsed;
    final String MESSAGE_WITH_LETTERS_TRIED = "Letters tried: ";

    TextView txtLettersTried;

    String lettersTried;
    TextView txtTriesLeft;
    String triesLeft = "XXXXX";
    final String WINNING_MESSAGE = "You won!";
    final String LOSING_MESSAGE = "You lost!";
    Animation rotateAnimation;
    Animation scaleAnimation;
    Animation scaleAndRotateAnimation;

    TableRow trReset;
    TableRow trTriesLeft;

    void revealLetterInWord(char letter) {
        int indexOfLetter = word_guess.indexOf(letter);

        // Loop if index is positive
        while (indexOfLetter >= 0) {
            wordDisplayedCharArray[indexOfLetter] = word_guess.charAt(indexOfLetter);
            indexOfLetter = word_guess.indexOf(letter, indexOfLetter + 1);
        }

        // Update the string as well
        wordDisplayedString = String.valueOf(wordDisplayedCharArray);
    }

    void displayWordOnScreen() {
        String formattedString = "";  //StringBuilder formattedString = new StringBuilder();
        for (char character : wordDisplayedCharArray) {
            formattedString += character + " ";  //formattedString.append(character).append(" ");
        }
        txtWord_Guess.setText(formattedString);  //txtWord_Guess.setText(formattedString.toString());
    }

    @SuppressLint("SetTextI18n")
    void initializeGame() {
        // Shuffle array list and get the first element, then remove it
        Collections.shuffle(wordbanks);
        word_guess = wordbanks.get(0);
        wordbanks.remove(0);

        // Initialize char array
        wordDisplayedCharArray = word_guess.toCharArray();

        // Add underscores
        for (int i = 1; i < wordDisplayedCharArray.length - 1; i++) {
            wordDisplayedCharArray[i] = '_';
        }

        // Reveal all occurrences of first and last character
        revealLetterInWord(wordDisplayedCharArray[0]);
        revealLetterInWord(wordDisplayedCharArray[wordDisplayedCharArray.length - 1]);

        // Initialize a string from this char array (for search purposes)
        wordDisplayedString = String.valueOf(wordDisplayedCharArray);

        // Display word
        displayWordOnScreen();

        // Clear input field
        editInput.setText("");

        // Initialize string for letters tried
        lettersUsed = " ";
        txtLettersUsed.setText(MESSAGE_WITH_LETTERS_TRIED + lettersUsed);

        // Display tries left
        lettersTried=" X X X X X";
        txtLettersTried.setText(lettersTried);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tablelayout);

        //Initialize variables
        wordbanks = new ArrayList<String>();
        txtWord_Guess = (TextView) findViewById(R.id.txtWord_Guess);
        editInput = (EditText) findViewById(R.id.editInput);
        txtLettersUsed = (TextView) findViewById(R.id.txtLettersUsed);
        txtLettersTried = (TextView) findViewById(R.id.txtLettersTried);
        rotateAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        scaleAnimation = AnimationUtils.loadAnimation(this, R.anim.scale);
        scaleAndRotateAnimation = AnimationUtils.loadAnimation(this, R.anim.scale_and_rotate);
        scaleAndRotateAnimation.setFillAfter(true);
        trReset = findViewById(R.id.trReset);
        trTriesLeft = findViewById(R.id.trTriesLeft);


        InputStream myInputStream = null;
        Scanner scanner = null;


        String aWord="";
            // Read and store words for the current level from assets
            try {
                myInputStream  = getAssets().open("Database.txt");
                scanner = new Scanner(myInputStream);

                while (scanner.hasNext()) {
                    aWord = scanner.next();
                    wordbanks.add(aWord);
                    Toast.makeText(MainActivity.this, aWord, Toast.LENGTH_SHORT).show();
                }

            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Error reading the file: " + "Database.txt", Toast.LENGTH_SHORT).show();
            }
            finally {
                if(scanner != null){
                    scanner.close();
                }
                try {
                    if(myInputStream != null) {
                        myInputStream.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Error reading the file: " + "Database.txt", Toast.LENGTH_SHORT).show();
                }

            }

             initializeGame();

        // Setup the text changed listener for the edit text
            editInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // If there is some letter in the input field
                if (s.length() != 0) {
                    checkIfLetterInWord(s.charAt(0));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    void checkIfLetterInWord(char letter) {
        // If the letter was found inside the word to be guessed
        if (word_guess.indexOf(letter) >= 0) {
            // If the letter was NOT displayed yet
            if (wordDisplayedString.indexOf(letter) < 0) {
                txtWord_Guess.startAnimation(scaleAnimation);
                // Replace the underscores with that letter
                revealLetterInWord(letter);

                // Update the changes on screen
                displayWordOnScreen();

                // Check if the game is won
                if (!wordDisplayedString.contains("_")) {
                    trTriesLeft.startAnimation(scaleAndRotateAnimation);
                    txtLettersTried.setText(WINNING_MESSAGE);
                }
            }
        } else {
            // Decrease the number of tries left, and display it on screen
            decreaseAndDisplayTriesLeft();

            // Check if the game is lost
            if (lettersTried.isEmpty()) {
                trTriesLeft.startAnimation(scaleAndRotateAnimation);
                txtLettersTried.setText(LOSING_MESSAGE);
                txtWord_Guess.setText(word_guess);
            }
        }

        // Display the letter that was tried
        if (lettersUsed.indexOf(letter) < 0) {
            lettersUsed += letter + ", ";
            String messageToBeDisplayed = MESSAGE_WITH_LETTERS_TRIED + lettersUsed;
            txtLettersUsed.setText(messageToBeDisplayed);
        }
    }

    void decreaseAndDisplayTriesLeft() {
        // If there are still some tries left
        if (!lettersTried.isEmpty()){
            txtLettersTried.startAnimation(scaleAnimation);
            // Take out the last 2 characters from this string
            lettersTried = lettersTried.substring(0, lettersTried.length() - 2);
            txtLettersTried.setText(lettersTried);
        }
    }

    void resetGame(View v) {
        // New game
        v.startAnimation(rotateAnimation);
        trReset.startAnimation(rotateAnimation);
        trTriesLeft.clearAnimation();
        initializeGame();
    }


}
