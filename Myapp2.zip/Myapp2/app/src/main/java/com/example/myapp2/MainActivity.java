package com.example.myapp2;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    TextView txtWord_Guess;
    String word_guess;
    EditText editInput;




    ArrayList<String> wordbanks;
    String wordDisplayedString;
    char[] wordDisplayedCharArray;

    TextView txtLettersUsed;

    String lettersUsed;
    final String MESSAGE_WITH_LETTERS_TRIED = "Letters used: ";

    TextView txtLettersTried;

    String lettersTried;
    final String WINNING_MESSAGE = "Congratulations You won!";
    final String LOSING_MESSAGE = "You lost!";


    void revealLetterInWord(char letter) {
        int indexOfLetter = word_guess.indexOf(letter);

        // Loop if index is positive
        while (indexOfLetter >= 0) {
            wordDisplayedCharArray[indexOfLetter] = word_guess.charAt(indexOfLetter);
            indexOfLetter = word_guess.indexOf(letter, indexOfLetter + 1);
        }

        // Update the string as well
        wordDisplayedString = String.valueOf(wordDisplayedCharArray);
    }

    void displayWordOnScreen() {
        StringBuilder formattedString = new StringBuilder();
        for (char character : wordDisplayedCharArray) {
            formattedString.append(character).append(" ");
        }
        txtWord_Guess.setText(formattedString.toString());
    }

    @SuppressLint("SetTextI18n")
    void initializeGame() {
        // Shuffle array list and get the first element, then remove it
        Collections.shuffle(wordbanks);
        word_guess = wordbanks.get(0);
        wordbanks.remove(0);

        // Initialize char array
        wordDisplayedCharArray = word_guess.toCharArray();

        //  underscores
        for (int i = 1; i < wordDisplayedCharArray.length - 1; i++) {
            wordDisplayedCharArray[i] = '_';
        }

        // Reveal all occurrences of first and last character
        revealLetterInWord(wordDisplayedCharArray[0]);
        revealLetterInWord(wordDisplayedCharArray[wordDisplayedCharArray.length - 1]);


        wordDisplayedString = String.valueOf(wordDisplayedCharArray);

        // Display word
        displayWordOnScreen();

        // Clear input field
        editInput.setText("");

        // Initialize string for letters tried
        lettersUsed = " ";
        txtLettersUsed.setText(MESSAGE_WITH_LETTERS_TRIED + lettersUsed);

        // Display tries left
        lettersTried=" X X X X X";
        txtLettersTried.setText(lettersTried);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tablelayout);

        //Initialize variables
        wordbanks = new ArrayList<>();
        txtWord_Guess = findViewById(R.id.txtWord_Guess);
        editInput = findViewById(R.id.editInput);
        txtLettersUsed = findViewById(R.id.txtLettersUsed);
        txtLettersTried = findViewById(R.id.txtLettersTried);



        InputStream myInputStream = null;
        Scanner scanner = null;


        String aWord;
        // Read and store words for the current level from assets
        try {
            myInputStream = getAssets().open("Database.txt");
            scanner = new Scanner(myInputStream);

            while (scanner.hasNext()) {
                aWord = scanner.next();
                wordbanks.add(aWord);
                Toast.makeText(MainActivity.this, aWord, Toast.LENGTH_SHORT).show();
            }

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error reading the file: " + "Database.txt", Toast.LENGTH_SHORT).show();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
            try {
                if (myInputStream != null) {
                    myInputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Error reading the file: " + "Database.txt", Toast.LENGTH_SHORT).show();
            }

        }

        initializeGame();

        // Setup the text changed listener for the edit text
        editInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // If there is some letter in the input field
                if (s.length() != 0) {
                    checkIfLetterInWord(s.charAt(0));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    void checkIfLetterInWord(char letter) {
        // If the letter was found inside the word to be guessed
        if (word_guess.indexOf(letter) >= 0) {
            // If the letter was NOT displayed yet
            if (wordDisplayedString.indexOf(letter) < 0) {

                // Replace the underscores with that letter
                revealLetterInWord(letter);

                // Update the changes on screen
                displayWordOnScreen();

                // Check if the game is won
                if (!wordDisplayedString.contains("_")) {
                    txtLettersTried.setText(WINNING_MESSAGE);
                }
            }
        } else {
            // Decrease the number of tries left, and display it on screen
            decreaseAndDisplayTriesLeft();

            // Check if the game is lost
            if (lettersTried.isEmpty()) {

                txtLettersTried.setText(LOSING_MESSAGE);
                txtWord_Guess.setText(word_guess);
            }
        }

        // Display the letter that was tried
        if (lettersUsed.indexOf(letter) < 0) {
            lettersUsed += letter + ", ";
            String messageToBeDisplayed = MESSAGE_WITH_LETTERS_TRIED + lettersUsed;
            txtLettersUsed.setText(messageToBeDisplayed);
        }
    }

    void decreaseAndDisplayTriesLeft() {
        // If there are still some tries left
        if (!lettersTried.isEmpty()){

            // Take out the last 2 characters from this string
            lettersTried = lettersTried.substring(0, lettersTried.length() - 2);
            txtLettersTried.setText(lettersTried);
        }
    }

    void resetGame() {
        // New game
        initializeGame();
    }


}
